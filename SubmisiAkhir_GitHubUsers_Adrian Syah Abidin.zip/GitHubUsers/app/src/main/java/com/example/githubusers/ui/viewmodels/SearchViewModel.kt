package com.example.githubusers.ui.viewmodels

import androidx.lifecycle.ViewModel
import com.example.githubusers.data.repository.UserRepository

class SearchViewModel(private val userRepository: UserRepository): ViewModel() {
    fun getSearchUsers(query: String) = userRepository.getSearchUsers(query)
}