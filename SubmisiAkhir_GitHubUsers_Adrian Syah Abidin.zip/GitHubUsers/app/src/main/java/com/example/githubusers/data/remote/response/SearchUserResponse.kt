package com.example.githubusers.data.remote.response

import com.example.githubusers.data.model.User
import com.google.gson.annotations.SerializedName

data class SearchUserResponse(
    @field:SerializedName("total_count")
    val totalCount: Int,

    @field:SerializedName("items")
    val users: List<User>
)
